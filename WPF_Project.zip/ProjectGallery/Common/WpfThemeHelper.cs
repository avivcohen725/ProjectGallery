﻿using System.Windows;

namespace Common;

public static class WpfThemeHelper {
	public static void SetTheme(string themeName, Window window) {
		
	}
}