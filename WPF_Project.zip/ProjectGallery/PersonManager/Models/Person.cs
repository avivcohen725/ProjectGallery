﻿namespace PersonManager.Models;

public class Person {
    public int ID { get; set; }
    public string Name { get; set; }
	public int Age { get; set; }
}